# Detection-Of-Phishing-Websites-Using-Machine-Learning


- Developed a project to target and prevent phishing attacks aimed at collecting private information
such as user identities, passwords, and online financial transactions
- Implemented a system to detect and prevent phishing threats by using machine learning techniques
- Increased awareness about the growing threat of phishing attacks and the importance of implementing
anti-phishing techniques
- Successfully utilized machine.
